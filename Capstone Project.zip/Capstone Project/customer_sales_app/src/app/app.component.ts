import { Component } from '@angular/core';
import { LoginService } from './login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'customer_sales_app';
  
  constructor(public _auth: LoginService) { }

  user = this._auth.userName;
}
